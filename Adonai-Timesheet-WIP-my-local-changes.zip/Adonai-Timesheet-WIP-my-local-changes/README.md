i found that 360dialog would work best for our project. most of the big companies in UAE already use it (lulu, KFC, LG, etc) whenever we're ready, we contact them so we can know their pricing and what not. Based on my research,
the should be the most cost effective option.

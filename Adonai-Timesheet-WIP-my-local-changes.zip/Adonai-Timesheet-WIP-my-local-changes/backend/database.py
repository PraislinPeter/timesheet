from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

<<<<<<< HEAD
=======

DB_URL = "mysql+pymysql://root:Adonai%401360@localhost/praiseAdonai"
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
DB_URL = "postgresql+psycopg2://postgres:root@localhost:5432/Adonai"

engine = create_engine(DB_URL)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()

# To apply the new User model, run this script once to create the users table if it does not exist.
from database import Base, engine
import models

if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    print("Database tables created.")

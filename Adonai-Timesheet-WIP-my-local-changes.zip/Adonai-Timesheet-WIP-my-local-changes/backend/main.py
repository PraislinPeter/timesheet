<<<<<<< HEAD
from fastapi import FastAPI, Depends, HTTPException, Query, status
=======

from fastapi import FastAPI, Depends, Query
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
from sqlalchemy.orm import Session
from sqlalchemy import func
from database import Base, engine, SessionLocal
from models import Timesheet, TimesheetEntry, Trade, Employee, User
from schemas import TimesheetIn, TimesheetEntryUpdate, TimesheetOut, TimesheetEntryIn, ReportOut, EmployeeOut, TimesheetEntryOut, TimesheetUpdate, TradeOut, UserCreate, UserLogin, UserOut
from fastapi.middleware.cors import CORSMiddleware
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from typing import List, Optional
import models
from datetime import datetime, date, timedelta
from collections import defaultdict
from fastapi import FastAPI, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from database import Base, engine, SessionLocal
from models import Timesheet, TimesheetEntry, Trade, Employee, User
from schemas import TimesheetIn, TimesheetEntryUpdate, TimesheetOut, TimesheetEntryIn, ReportOut, EmployeeOut, TimesheetEntryOut, TimesheetUpdate, TradeOut, UserCreate, UserLogin, UserOut
from fastapi.middleware.cors import CORSMiddleware
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from models import Employee
from schemas import EmployeeOut
from typing import List, Optional
import models
from datetime import datetime, date, timedelta
from collections import defaultdict  
from models import Timesheet, TimesheetEntry
app = FastAPI()
from fastapi import FastAPI, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from database import Base, engine, SessionLocal
from models import Timesheet, TimesheetEntry, Trade, Employee, User
from schemas import TimesheetIn, TimesheetEntryUpdate, TimesheetOut, TimesheetEntryIn, TimesheetEntryOut


app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def get_user(db, username: str):
    return db.query(User).filter(User.username == username).first()

def authenticate_user(db, username: str, password: str):
    user = get_user(db, username)
    if not user or not verify_password(password, user.hashed_password):
        return False
    return user

async def get_current_user(token: str = Depends(OAuth2PasswordBearer(tokenUrl="/token")), db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = get_user(db, username=username)
    if user is None:
        raise credentials_exception
    return user

# --- SALARY VIEW ENDPOINT ---
@app.get("/salary", response_model=List[dict])
def get_salary_view(start: date = Query(...), end: date = Query(...), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    # Get all employees
    employees = db.query(Employee).all()
    # Get all timesheets in range
    timesheets = db.query(Timesheet).filter(Timesheet.date >= start, Timesheet.date <= end).all()
    timesheet_ids = [ts.id for ts in timesheets]
    # Get all entries in range
    entries = db.query(TimesheetEntry).filter(TimesheetEntry.timesheet_id.in_(timesheet_ids)).all()
    # Map emp_no to employee
    emp_map = {e.emp_no: e for e in employees}
    # Aggregate hours and pay
    salary_data = {}
    for entry in entries:
        emp = emp_map.get(entry.employee_emp_no)
        if not emp:
            continue
        if emp.emp_no not in salary_data:
            salary_data[emp.emp_no] = {
                "emp_no": emp.emp_no,
                "name": emp.name,
                "base_pay": float(emp.base_pay),
                "total_hours": 0.0,
                "total_pay": 0.0
            }
        salary_data[emp.emp_no]["total_hours"] += float(entry.total_hours or 0)
    # Calculate pay
    for emp_no, data in salary_data.items():
        data["total_pay"] = round(data["total_hours"] * data["base_pay"], 2)
        data["total_hours"] = round(data["total_hours"], 2)
    return list(salary_data.values())

from fastapi import FastAPI, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from database import Base, engine, SessionLocal
from models import Timesheet, TimesheetEntry, Trade, Employee, User
from schemas import TimesheetIn, TimesheetEntryUpdate, TimesheetOut, TimesheetEntryIn, ReportOut, EmployeeOut, TimesheetEntryOut, TimesheetUpdate, TradeOut, UserCreate, UserLogin, UserOut
from fastapi.middleware.cors import CORSMiddleware
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from typing import List, Optional
import models
from datetime import datetime, date, timedelta
from collections import defaultdict
from fastapi import FastAPI, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from database import Base, engine, SessionLocal
from models import Timesheet, TimesheetEntry, Trade, Employee, User
from schemas import TimesheetIn, TimesheetEntryUpdate, TimesheetOut, TimesheetEntryIn, ReportOut, EmployeeOut, TimesheetEntryOut, TimesheetUpdate, TradeOut, UserCreate, UserLogin, UserOut
from fastapi.middleware.cors import CORSMiddleware
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from models import Employee
from schemas import EmployeeOut
from typing import List, Optional
import models
from datetime import datetime, date, timedelta
from collections import defaultdict  
from models import Timesheet, TimesheetEntry
app = FastAPI()
from fastapi import FastAPI, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from database import Base, engine, SessionLocal
from models import Timesheet, TimesheetEntry, Trade, Employee, User
from schemas import TimesheetIn, TimesheetEntryUpdate, TimesheetOut, TimesheetEntryIn, TimesheetEntryOut


app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def get_user(db, username: str):
    return db.query(User).filter(User.username == username).first()

def authenticate_user(db, username: str, password: str):
    user = get_user(db, username)
    if not user or not verify_password(password, user.hashed_password):
        return False
    return user

async def get_current_user(token: str = Depends(OAuth2PasswordBearer(tokenUrl="/token")), db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = get_user(db, username=username)
    if user is None:
        raise credentials_exception
    return user

# --- SALARY VIEW ENDPOINT ---
@app.get("/salary", response_model=List[dict])
def get_salary_view(start: date = Query(...), end: date = Query(...), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    # Get all employees
    employees = db.query(Employee).all()
    # Get all timesheets in range
    timesheets = db.query(Timesheet).filter(Timesheet.date >= start, Timesheet.date <= end).all()
    timesheet_ids = [ts.id for ts in timesheets]
    # Get all entries in range
    entries = db.query(TimesheetEntry).filter(TimesheetEntry.timesheet_id.in_(timesheet_ids)).all()
    # Map emp_no to employee
    emp_map = {e.emp_no: e for e in employees}
    # Aggregate hours and pay
    salary_data = {}
    for entry in entries:
        emp = emp_map.get(entry.employee_emp_no)
        if not emp:
            continue
        if emp.emp_no not in salary_data:
            salary_data[emp.emp_no] = {
                "emp_no": emp.emp_no,
                "name": emp.name,
                "base_pay": float(emp.base_pay),
                "total_hours": 0.0,
                "total_pay": 0.0
            }
        salary_data[emp.emp_no]["total_hours"] += float(entry.total_hours or 0)
    # Calculate pay
    for emp_no, data in salary_data.items():
        data["total_pay"] = round(data["total_hours"] * data["base_pay"], 2)
        data["total_hours"] = round(data["total_hours"], 2)
    return list(salary_data.values())

Base.metadata.create_all(bind=engine)

<<<<<<< HEAD
=======

app = FastAPI()
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
# --- AUTH SETUP ---
SECRET_KEY = "supersecretkey"  # Change this in production
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def get_user(db, username: str):
    return db.query(User).filter(User.username == username).first()

def authenticate_user(db, username: str, password: str):
    user = get_user(db, username)
    if not user or not verify_password(password, user.hashed_password):
        return False
    return user

async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(lambda: SessionLocal())):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = get_user(db, username=username)
    if user is None:
        raise credentials_exception
    return user


# CORS for React
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)

<<<<<<< HEAD
=======

>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
# --- AUTH ENDPOINTS ---
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/register", response_model=UserOut)
def register(user: UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(User).filter(User.username == user.username).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Username already registered")
    hashed_password = get_password_hash(user.password)
    new_user = User(username=user.username, hashed_password=hashed_password)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

from fastapi import Request

@app.post("/login")
async def login(request: Request, db: Session = Depends(get_db)):
    # Try to parse as form data first
    try:
        form = await request.form()
        username = form.get("username")
        password = form.get("password")
    except Exception:
        username = None
        password = None

    # If not form, try JSON
    if not username or not password:
        try:
            data = await request.json()
            username = data.get("username")
            password = data.get("password")
        except Exception:
            pass

    if not username or not password:
        raise HTTPException(status_code=400, detail="Username and password required")

    user = authenticate_user(db, username, password)
    if not user:
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    access_token = create_access_token(
        data={"sub": user.username},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    return {"access_token": access_token, "token_type": "bearer"}
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/employees", response_model=List[EmployeeOut])
def get_employees(db: Session = Depends(get_db)):
    return db.query(Employee).all()

@app.post("/employees", response_model=EmployeeOut)
def create_employee(employee: EmployeeOut, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    db_emp = Employee(emp_no=employee.emp_no, name=employee.name, base_pay=employee.base_pay)
    db.add(db_emp)
    db.commit()
    db.refresh(db_emp)
    return db_emp

@app.put("/employees/{emp_no}", response_model=EmployeeOut)
def update_employee(emp_no: str, employee: EmployeeOut, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    db_emp = db.query(Employee).filter(Employee.emp_no == emp_no).first()
    if not db_emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    db_emp.name = employee.name
    db_emp.base_pay = employee.base_pay
    db.commit()
    db.refresh(db_emp)
    return db_emp

@app.delete("/employees/{emp_no}")
def delete_employee(emp_no: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    db_emp = db.query(Employee).filter(Employee.emp_no == emp_no).first()
    if not db_emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    db.delete(db_emp)
    db.commit()
    return {"message": "Employee deleted"}

@app.post("/timesheets")
<<<<<<< HEAD
def create_timesheet(timesheet: TimesheetIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
=======
def create_timesheet(timesheet: TimesheetIn, db: Session = Depends(get_db)):

@app.post("/employees", response_model=EmployeeOut)
def create_employee(employee: EmployeeOut, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    db_emp = Employee(emp_no=employee.emp_no, name=employee.name, base_pay=employee.base_pay)
    db.add(db_emp)
    db.commit()
    db.refresh(db_emp)
    return db_emp

@app.put("/employees/{emp_no}", response_model=EmployeeOut)
def update_employee(emp_no: str, employee: EmployeeOut, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    db_emp = db.query(Employee).filter(Employee.emp_no == emp_no).first()
    if not db_emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    db_emp.name = employee.name
    db_emp.base_pay = employee.base_pay
    db.commit()
    db.refresh(db_emp)
    return db_emp

@app.delete("/employees/{emp_no}")
def delete_employee(emp_no: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    db_emp = db.query(Employee).filter(Employee.emp_no == emp_no).first()
    if not db_emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    db.delete(db_emp)
    db.commit()
    return {"message": "Employee deleted"}


@app.post("/timesheets")
def create_timesheet(timesheet: TimesheetIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):

>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
    ts = Timesheet(**{k: v for k, v in timesheet.dict().items() if k != "entries"})
    db.add(ts)
    db.commit()
    db.refresh(ts)

    for entry in timesheet.entries:
        db.add(TimesheetEntry(timesheet_id=ts.id, **entry.dict()))
    db.commit()

    return {"status": "success", "timesheet_id": ts.id}
from datetime import timedelta
def get_date_range(start: date, end: date):
    current = start
    while current <= end:
        yield current
        current += timedelta(days=1)

@app.get("/reports/summary")
def get_summary(start: date = Query(...), end: date = Query(...), db: Session = Depends(get_db)):
    # 1. Build full date list
    all_dates = [d.strftime("%Y-%m-%d") for d in get_date_range(start, end)]

    # 2. Get timesheets and entries
    timesheets = db.query(Timesheet).filter(Timesheet.date >= start, Timesheet.date <= end).all()
    timesheet_map = {ts.id: ts.date for ts in timesheets}
    timesheet_ids = list(timesheet_map.keys())

    # 3. Get all employees
    employees = db.query(Employee).all()
    employee_map = {emp.emp_no: emp.name for emp in employees}

    # 4. Initialize report structure
    report = {
        emp.emp_no: {
            "emp_no": emp.emp_no,
            "employee_name": emp.name,
            "entries_by_date": {
                date_str: {"total_hours": 0.0, "timesheet_ids": []}
                for date_str in all_dates
            }
        }
        for emp in employees
    }

    # 5. Fill in timesheet entries
    if timesheet_ids:
        entries = db.query(TimesheetEntry).filter(TimesheetEntry.timesheet_id.in_(timesheet_ids)).all()

        for entry in entries:
            emp_id = entry.employee_emp_no
            if emp_id not in report:
                continue
            ts_date = timesheet_map[entry.timesheet_id].strftime("%Y-%m-%d")
            entry_data = report[emp_id]["entries_by_date"][ts_date]
            entry_data["total_hours"] += float(entry.total_hours or 0)
            entry_data["timesheet_ids"].append(entry.timesheet_id)

    # 6. Calculate total, normal OT, holiday OT
    for emp in report.values():
        total = 0.0
        hot = 0.0
        not_ = 0.0

        for date_str, entry in emp["entries_by_date"].items():
            hrs = entry["total_hours"]
            total += hrs
            dt = datetime.strptime(date_str, "%Y-%m-%d")
            if dt.weekday() == 6:  # Sunday
                hot += hrs
            elif hrs > 8:
                not_ += hrs - 8

        emp["total_hours"] = round(total, 2)
        emp["holiday_ot"] = round(hot, 2)
        emp["normal_ot"] = round(not_, 2)

    return list(report.values())

@app.get("/timesheets", response_model=List[TimesheetOut])
def get_all_timesheets(db: Session = Depends(get_db)):
    timesheets = db.query(Timesheet).all()
    for ts in timesheets:
        ts.entries = db.query(TimesheetEntry).filter_by(timesheet_id=ts.id).all()
    return timesheets

@app.put("/time-entries/{entry_id}")
<<<<<<< HEAD
def update_time_entry(entry_id: int, data: TimesheetEntryUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
=======

def update_time_entry(entry_id: int, data: TimesheetEntryUpdate, db: Session = Depends(get_db)):
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
    entry = db.query(TimesheetEntry).filter_by(id=entry_id).first()
    if not entry:
        raise HTTPException(status_code=404, detail="Entry not found")
    for key, value in data.dict(exclude_unset=True).items():
        setattr(entry, key, value)
<<<<<<< HEAD
=======


def update_time_entry(entry_id: int, data: TimesheetEntryUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    entry = db.query(TimesheetEntry).filter_by(id=entry_id).first()
    if not entry:
        raise HTTPException(status_code=404, detail="Entry not found")
    for key, value in data.dict(exclude_unset=True).items():
        setattr(entry, key, value)
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
    db.commit()
    db.refresh(entry)
    return {"message": "Entry updated", "entry": entry.id}

@app.get("/timesheets/details", response_model=List[TimesheetOut])
def get_timesheets_by_ids(timesheet_ids: List[int] = Query(...), db: Session = Depends(get_db)):
    timesheets = db.query(Timesheet).filter(Timesheet.id.in_(timesheet_ids)).all()
    if not timesheets:
        raise HTTPException(status_code=404, detail="No timesheets found for provided IDs")
    
    # Attach entries for each timesheet
    for timesheet in timesheets:
        timesheet.entries = db.query(TimesheetEntry).filter_by(timesheet_id=timesheet.id).all()
    
    return timesheets

@app.get("/timesheets/{timesheet_id}", response_model=TimesheetOut)
def get_timesheet_by_id(timesheet_id: int, db: Session = Depends(get_db)):
    # Fetch timesheet object
    timesheet = db.query(Timesheet).filter(Timesheet.id == timesheet_id).first()
    if not timesheet:
        raise HTTPException(status_code=404, detail="Timesheet not found")

    # ⬇️ JOIN Employee and Trade here
    results = (
        db.query(
            TimesheetEntry.id,
            TimesheetEntry.employee_emp_no.label("employee_emp_no"),
            TimesheetEntry.trade_id,
            Employee.name.label("employee_name"),
            Trade.trade_name.label("trade_name"),
            TimesheetEntry.from_time,
            TimesheetEntry.to_time,
            TimesheetEntry.break_minutes,
            TimesheetEntry.total_hours,
            TimesheetEntry.remarks
        )
        .join(Employee, TimesheetEntry.employee_emp_no == Employee.emp_no)
        .join(Trade, TimesheetEntry.trade_id == Trade.id)
        .filter(TimesheetEntry.timesheet_id == timesheet.id)
        .all()
    )

    timesheet.entries = [
    TimesheetEntryOut(
        id=row.id,
        employee_emp_no=row.employee_emp_no,
        employee_name=row.employee_name,
        trade_id=row.trade_id,
        trade_name=row.trade_name,
        from_time=row.from_time.strftime("%H:%M") if row.from_time else None,
        to_time=row.to_time.strftime("%H:%M") if row.to_time else None,
        break_minutes=row.break_minutes,
        total_hours=row.total_hours,
        remarks=row.remarks
    )
    for row in results
]



    return timesheet



    
@app.put("/timesheets/{timesheet_id}")
<<<<<<< HEAD
def update_timesheet(timesheet_id: int, data: TimesheetUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
=======

def update_timesheet(timesheet_id: int, data: TimesheetUpdate, db: Session = Depends(get_db)):
    print("Data received:", data)
    print("Parsed date type:", type(data.date))

>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
    timesheet = db.query(Timesheet).filter_by(id=timesheet_id).first()
    if not timesheet:
        raise HTTPException(status_code=404, detail="Timesheet not found")
    for key, value in data.dict(exclude_unset=True).items():
        setattr(timesheet, key, value)
<<<<<<< HEAD
    db.commit()
=======


def update_timesheet(timesheet_id: int, data: TimesheetUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    timesheet = db.query(Timesheet).filter_by(id=timesheet_id).first()
    if not timesheet:
        raise HTTPException(status_code=404, detail="Timesheet not found")
    for key, value in data.dict(exclude_unset=True).items():
        setattr(timesheet, key, value)
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
    db.refresh(timesheet)
    return {"message": "Timesheet updated", "timesheet_id": timesheet.id}

@app.get("/employees", response_model=List[EmployeeOut])
def get_employees(db: Session = Depends(get_db)):
    return db.query(Employee).all()


@app.get("/trades", response_model=List[TradeOut])
def get_trades(db: Session = Depends(get_db)):
    return db.query(Trade).all()

from typing import List

<<<<<<< HEAD
=======


>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
from fastapi.openapi.utils import get_openapi
from fastapi.security import OAuth2PasswordBearer
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Timesheet API",
        version="1.0.0",
        description="API for Timesheet App with JWT Auth",
        routes=app.routes,
    )
    openapi_schema["components"]["securitySchemes"] = {
        "OAuth2PasswordBearer": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT"
        }
    }
    for path in openapi_schema["paths"].values():
        for op in path.values():
            op["security"] = [{"OAuth2PasswordBearer": []}]
    app.openapi_schema = openapi_schema
    return app.openapi_schema
app.openapi = custom_openapi

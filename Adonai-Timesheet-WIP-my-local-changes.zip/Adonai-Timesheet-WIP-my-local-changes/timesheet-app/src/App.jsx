
import React from "react";
import { Routes, Route, useLocation, Navigate } from "react-router-dom";
import Navbar from "./Navbar";
import TimesheetForm from "./TimesheetForm";
import TimesheetReport from "./TimesheetReport";
import TimesheetManager from "./TimesheetManager";
import TimesheetViewer from "./TimesheetViewer";
import TimesheetDetail from "./TimesheetDetail";
import SalaryView from "./SalaryView";
import Login from "./Login";
import './App.css';

// Simple auth check
const isAuthenticated = () => {
  return !!localStorage.getItem("token");
};

<<<<<<< HEAD

=======
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
const PrivateRoute = ({ children }) => {
  return isAuthenticated() ? children : <Navigate to="/login" replace />;
};

const App = () => {
  const location = useLocation();
  const isLoginPage = location.pathname === "/login";
  return (
    <div className="app-root d-flex">
      {!isLoginPage && <Navbar />}
      <div className="main-content-wrapper">
        <div className="main-content-inner">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<PrivateRoute><TimesheetForm /></PrivateRoute>} />
            <Route path="/salary" element={<PrivateRoute><SalaryView /></PrivateRoute>} />
            <Route path="/total-hours" element={<PrivateRoute><TimesheetReport /></PrivateRoute>} />
            <Route path="/manage-timesheets" element={<PrivateRoute><TimesheetManager /></PrivateRoute>} />
            <Route path="/timesheet/:id" element={<PrivateRoute><TimesheetDetail /></PrivateRoute>} />
            <Route path="/timesheets/view" element={<PrivateRoute><TimesheetViewer /></PrivateRoute>} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default App;



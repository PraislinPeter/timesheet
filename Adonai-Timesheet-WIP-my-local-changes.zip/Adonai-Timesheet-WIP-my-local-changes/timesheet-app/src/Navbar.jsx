import React, { useState } from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  const [collapsed, setCollapsed] = useState(false);
  return (
    <>
      <div
        className="text-white p-4 navbar-sidebar"
        style={{
          backgroundColor: "#0c2a64",
          width: collapsed ? "0px" : "330px",
          minWidth: collapsed ? "0px" : "330px",
          height: "100vh",
          position: "fixed",
          top: 0,
          left: 0,
          overflowY: "auto",
          fontSize: "1.5rem",
<<<<<<< HEAD
          transition: "width 0.3s, min-width 0.3s, padding 0.3s, opacity 0.3s, visibility 0.3s",
          borderRight: collapsed ? 'none' : '1px solid #123',
          padding: collapsed ? '0 0' : '2rem',
          opacity: collapsed ? 0 : 1,
          visibility: collapsed ? 'hidden' : 'visible',
          pointerEvents: collapsed ? 'none' : 'auto',
=======
          transition:
            "width 0.3s, min-width 0.3s, padding 0.3s, opacity 0.3s, visibility 0.3s",
          borderRight: collapsed ? "none" : "1px solid #123",
          padding: collapsed ? "0 0" : "2rem",
          opacity: collapsed ? 0 : 1,
          visibility: collapsed ? "hidden" : "visible",
          pointerEvents: collapsed ? "none" : "auto",
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
        }}
      >
        {/* Title */}
        {!collapsed && <h3 className="fw-bold mb-5">Timesheet App</h3>}
        {!collapsed && (
          <ul className="nav flex-column">
            <li className="nav-item mb-5">
              <Link to="/" className="nav-link text-white">
<<<<<<< HEAD
                <span role="img" aria-label="sheet" style={{ marginRight: 8 }}>&#128221;</span> Enter Timesheet
=======
                <span
                  role="img"
                  aria-label="sheet"
                  style={{ marginRight: 8 }}
                >
                  &#128221;
                </span>{" "}
                Enter Timesheet
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
              </Link>
            </li>
            <li className="nav-item mb-5">
              <Link to="/salary" className="nav-link text-white">
<<<<<<< HEAD
                <span role="img" aria-label="money" style={{ marginRight: 8 }}>&#128181;</span> View Salary
=======
                <span
                  role="img"
                  aria-label="money"
                  style={{ marginRight: 8 }}
                >
                  &#128181;
                </span>{" "}
                View Salary
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
              </Link>
            </li>
            <li className="nav-item mb-5">
              <Link to="/total-hours" className="nav-link text-white">
<<<<<<< HEAD
                <span role="img" aria-label="clock" style={{ marginRight: 8 }}>&#128337;</span> Total Hours
=======
                <span
                  role="img"
                  aria-label="clock"
                  style={{ marginRight: 8 }}
                >
                  &#128337;
                </span>{" "}
                Total Hours
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
              </Link>
            </li>
            <li className="nav-item mb-5">
              <Link to="/manage-timesheets" className="nav-link text-white">
<<<<<<< HEAD
                <span role="img" aria-label="manage" style={{ marginRight: 8 }}>&#9881;&#65039;</span> Manage Timesheets
=======
                <span
                  role="img"
                  aria-label="manage"
                  style={{ marginRight: 8 }}
                >
                  &#9881;&#65039;
                </span>{" "}
                Manage Timesheets
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
              </Link>
            </li>
            {/* Logout Button */}
            <li className="nav-item mb-5">
              <button
                className="btn btn-danger w-100"
                onClick={() => {
                  localStorage.removeItem("token");
                  window.location.href = "/login";
                }}
              >
                Logout
              </button>
            </li>
          </ul>
        )}
      </div>
      {/* Arrow absolutely positioned, vertically centered, slightly overlapping sidebar */}
      <button
        onClick={() => setCollapsed((c) => !c)}
        style={{
          background: "#0c2a64",
          border: "none",
          color: "#fff",
          fontSize: "2rem",
          position: "fixed",
<<<<<<< HEAD
          top: '50%',
          left: collapsed ? 0 : 312, // overlap sidebar edge
          transform: 'translateY(-50%)',
          zIndex: 1000,
          width: 48,
          height: 48,
          borderRadius: '50%',
          boxShadow: '0 2px 8px rgba(0,0,0,0.12)',
          outline: 'none',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'left 0.3s',
          cursor: 'pointer',
=======
          top: "50%",
          left: collapsed ? 0 : 312, // overlap sidebar edge
          transform: "translateY(-50%)",
          zIndex: 1000,
          width: 48,
          height: 48,
          borderRadius: "50%",
          boxShadow: "0 2px 8px rgba(0,0,0,0.12)",
          outline: "none",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          transition: "left 0.3s",
          cursor: "pointer",
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
        }}
        aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        tabIndex={0}
<<<<<<< HEAD
        onMouseDown={e => e.preventDefault()} // Prevent blue outline
        onFocus={e => e.target.style.boxShadow = '0 2px 8px rgba(0,0,0,0.12)'}
        onBlur={e => e.target.style.boxShadow = '0 2px 8px rgba(0,0,0,0.12)'}
=======
        onMouseDown={(e) => e.preventDefault()} // Prevent blue outline
        onFocus={(e) => (e.target.style.boxShadow = "0 2px 8px rgba(0,0,0,0.12)")}
        onBlur={(e) => (e.target.style.boxShadow = "0 2px 8px rgba(0,0,0,0.12)")}
>>>>>>> 23f69ec (added some stuff, will still need polishing but basically done with the app. check README file for info about whatsapp notification implementation)
      >
        {collapsed ? <span>&#x25B6;</span> : <span>&#x25C0;</span>}
      </button>
    </>
  );
};
export default Navbar;

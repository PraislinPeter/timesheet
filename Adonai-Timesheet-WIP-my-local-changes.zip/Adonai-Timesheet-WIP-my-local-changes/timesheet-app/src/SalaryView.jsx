import React, { useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import axios from "axios";

const SalaryView = () => {
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [salaryData, setSalaryData] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchSalary = async () => {
    setError("");
    setSalaryData([]);
    if (!startDate || !endDate) {
      setError("Please select both start and end dates.");
      return;
    }
    setLoading(true);
    try {
      // Get token from localStorage or sessionStorage
      const token = localStorage.getItem("token") || sessionStorage.getItem("token");
      const res = await axios.get(
        `http://localhost:8000/salary?start=${startDate.toISOString().slice(0, 10)}&end=${endDate.toISOString().slice(0, 10)}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setSalaryData(res.data);
    } catch (err) {
      setError("Failed to fetch salary data. Make sure you are logged in.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="salary-view-outer">
      <div className="salary-view-inner">
        <h2 className="text-center mb-4">Salary View</h2>
        <div className="d-flex flex-wrap gap-4 mb-3 justify-content-center align-items-end salary-input-row">
          <div className="d-flex flex-column align-items-start">
            <label className="mb-1" style={{ fontWeight: 500, fontSize: '1rem', minWidth: 90 }}>Start Date</label>
            <DatePicker
              selected={startDate}
              onChange={setStartDate}
              dateFormat="yyyy-MM-dd"
              className="form-control"
              placeholderText="Start date"
              style={{ minWidth: 140 }}
            />
          </div>
          <div className="d-flex flex-column align-items-start">
            <label className="mb-1" style={{ fontWeight: 500, fontSize: '1rem', minWidth: 90 }}>End Date</label>
            <DatePicker
              selected={endDate}
              onChange={setEndDate}
              dateFormat="yyyy-MM-dd"
              className="form-control"
              placeholderText="End date"
              style={{ minWidth: 140 }}
            />
          </div>
          <div className="align-self-end">
            <button className="btn btn-primary" onClick={fetchSalary} disabled={loading}>
              {loading ? "Loading..." : "View Salary"}
            </button>
          </div>
        </div>
        {error && <div className="text-danger mb-3 text-center">{error}</div>}
        {salaryData.length > 0 && (
          <div className="table-responsive">
            <table className="table table-bordered mt-4 text-center">
              <thead className="table-light">
                <tr>
                  <th>Employee No</th>
                  <th>Name</th>
                  <th>Base Pay</th>
                  <th>Total Hours</th>
                  <th>Total Pay</th>
                </tr>
              </thead>
              <tbody>
                {salaryData.map((row) => (
                  <tr key={row.emp_no}>
                    <td>{row.emp_no}</td>
                    <td>{row.name}</td>
                    <td>{row.base_pay}</td>
                    <td>{row.total_hours}</td>
                    <td>{row.total_pay}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default SalaryView;
